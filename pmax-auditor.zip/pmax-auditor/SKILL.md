---
name: pmax-auditor
description: Comprehensive Performance Max campaign audit framework for Google Ads. Use when evaluating PMax campaign health, identifying optimization opportunities, analyzing asset performance, verifying conversion tracking, assessing budget allocation, or generating audit reports. Covers campaign structure, asset groups, audience signals, and performance benchmarking across Search, Display, YouTube, Gmail, and Maps inventory.
---

# Performance Max Campaign Auditor

Comprehensive audit framework for Performance Max campaigns covering conversion tracking, asset groups, budget adequacy, audience signals, and performance benchmarking.

## Audit Framework (6 Critical Components)

### 1. Conversion Tracking Verification

**Critical checks:**
- Primary conversion action set correctly (not secondary)
- Google Ads Tag implemented (verify via Tag Assistant or Goals > Diagnostics)
- Enhanced Conversions configured for first-party data
- Data-driven attribution model active
- Conversion import working (if using GA4/CRM data)

**API Query:**
```sql
SELECT 
  conversion_action.id,
  conversion_action.name,
  conversion_action.status,
  conversion_action.primary_for_goal,
  conversion_action.attribution_model_settings.attribution_model
FROM conversion_action
WHERE conversion_action.status = 'ENABLED'
```

### 2. Asset Group Analysis

**Asset completeness requirements:**
- Headlines: 5 minimum, 15 maximum (30 chars each)
- Long headlines: 1 minimum, 5 maximum (90 chars each)
- Descriptions: 2 minimum, 5 maximum (90 chars each)
- Images: 20 maximum (multiple aspect ratios required)
- Videos: 1+ custom video

**Ad Strength ratings:** Incomplete → Poor → Average → Good → Excellent

**Performance impact:** Improving from Poor to Excellent yields 6% increase in conversions

**API Query for asset performance:**
```sql
SELECT 
  asset_group_asset.performance_label,
  asset_group_asset.field_type,
  asset.name,
  asset.type,
  asset_group.name
FROM asset_group_asset
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
```

Performance labels: BEST, GOOD, LOW, LEARNING, PENDING, NOT_APPLICABLE

**Action threshold:** Replace LOW-rated assets within 14 days

### 3. Budget Adequacy Assessment

**Minimum budget formula:** Daily budget ≥ 3x target CPA

**Conversion volume requirements:**
- Minimum: 30-60 conversions monthly for optimization
- Optimal: 100+ conversions/day enables 1-3 day learning
- Insufficient data: <30 conversions/month extends learning to 14+ days

**Budget pacing check:**
- Limited by budget: Increase budget 20-30%
- Meeting targets: Budget adequate
- Under-spending: Review targeting/creative/bids

### 4. Audience Signal Evaluation

**Signal types:**
- Custom segments (first-party data)
- Your data (customer lists, website visitors)
- Demographics (age, gender, parental status)
- Interests (affinity, in-market)

**Quality indicators:**
- Signals with performance data available
- Sufficient audience size (10,000+ for most accounts)
- Alignment with conversion patterns

### 5. Campaign Structure Review

**Campaign count optimization:**
- Separate campaigns by conversion goals (leads vs. sales)
- Separate by budget tiers
- Geographic segmentation where relevant
- Avoid over-fragmentation (<30 conversions/month per campaign)

**Asset group structure:**
- 1-3 asset groups per campaign typically
- Segment by product category or audience intent
- Each with unique value propositions

### 6. Performance vs. Benchmarks

**Benchmark comparison:**

| Metric | Below Average | Acceptable | Strong | High Performer |
|--------|---------------|------------|--------|----------------|
| ROAS | <200% | 200-400% | 400%+ | 600%+ |
| CPA | Context-dependent | ~$15.15 | Below target | <$10 |
| CVR | <2% | ~3.47% | >4% | >5% |

**2024 Performance data:**
- Average PMax ROAS: 616% (Q3 2024)
- Top performers: 993%+ ROAS
- Average CVR: 3.47%

## Health Score Calculation (100-Point System)

| Component | Weight | Scoring Criteria |
|-----------|--------|------------------|
| Conversion Tracking | 20 pts | Proper setup (20), Minor issues (10), Broken (0) |
| Ad Strength | 15 pts | Excellent (15), Good (12), Average (8), Poor (4) |
| Asset Coverage | 15 pts | Full coverage (15), 75%+ (10), <50% (0) |
| Performance vs Target | 20 pts | Exceeds (20), Meets (15), Within 10% (10) |
| Budget Adequacy | 10 pts | 3x+ CPA (10), 2x CPA (7), <2x CPA (3) |
| Learning Phase | 10 pts | Exited (10), Progressing (5), Stuck (0) |
| Asset Performance | 10 pts | No LOW assets (10), 1-2 LOW (5), 3+ LOW (0) |

**Score interpretation:**
- 90-100: Excellent health, ready for scaling
- 75-89: Good health, minor optimizations needed
- 60-74: Fair health, action items required
- <60: Critical issues, immediate intervention needed

## Google Ads API Integration

**Campaign performance retrieval:**
```sql
SELECT 
  campaign.id,
  campaign.name,
  campaign.status,
  campaign.bidding_strategy_type,
  metrics.conversions,
  metrics.conversion_value,
  metrics.cost_micros,
  metrics.clicks,
  metrics.impressions,
  campaign_budget.amount_micros
FROM campaign
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
  AND segments.date DURING LAST_30_DAYS
```

**Asset group insights:**
```sql
SELECT
  asset_group.id,
  asset_group.name,
  asset_group.ad_strength,
  asset_group.status,
  metrics.conversions,
  metrics.cost_micros
FROM asset_group
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
```

## Common Issues and Fixes

### Issue: Low Ad Strength
**Causes:** Insufficient headlines/descriptions, repetitive content, missing long headlines
**Fix:** Add unique assets, use dynamic insertion, include calls-to-action

### Issue: Extended Learning Phase
**Causes:** Insufficient conversions (<30/month), frequent changes, budget constraints
**Fix:** Increase budget, consolidate campaigns, pause changes for 7-14 days

### Issue: High CPA
**Causes:** Poor audience signals, weak creative, unrealistic targets
**Fix:** Refine audience signals, refresh creative, adjust target ROAS/CPA

### Issue: LOW Asset Performance
**Causes:** Poor quality images, weak copy, off-brand messaging
**Fix:** Replace with variations of BEST performers, test new angles

## Audit Report Structure

**Executive Summary:**
- Overall health score
- Key findings (top 3 issues)
- Recommended actions with priority

**Detailed Findings:**
1. Conversion tracking status
2. Asset performance breakdown
3. Budget and pacing analysis
4. Performance vs. benchmarks
5. Competitive positioning

**Action Plan:**
- Immediate fixes (critical)
- Short-term optimizations (1-2 weeks)
- Long-term strategy (1-3 months)

## Automation Opportunities

**Weekly automated checks:**
- Asset performance degradation alerts
- Budget pacing notifications
- Conversion tracking errors
- Learning phase status
- Performance anomaly detection

**Monthly comprehensive audit:**
- Full health score calculation
- Benchmark comparison
- Competitive analysis
- Strategic recommendations

## Integration with Other Skills

- **search-terms:** Analyze PMax search term reports for negative keywords
- **rsa-generator:** Apply RSA best practices to PMax headlines
- **negative-keywords:** Implement discovered negatives from PMax queries

For detailed API documentation, see references/google-ads-api.md
For audit report templates, see references/audit-templates.md
